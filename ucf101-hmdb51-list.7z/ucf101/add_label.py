def add_label(cls_idx_file, pre_pre_file, pre_file):
	of = open(pre_file, 'w')
	cls_idx_d = {}
	with open(cls_idx_file, 'r') as f:
		for line in f:
			idx = int(line.strip().split(' ')[0])-1
			cls = line.strip().split(' ')[1]
			cls_idx_d[cls] = idx

	with open(pre_pre_file, 'r') as f:
		for line in f:
			line = line.strip()
			cls = line.split(' ')[0].split('v_')[1].split('_g')[0]
			idx = cls_idx_d[cls]
			new_line = line + ' ' + str(idx) + '\n'
			of.write(new_line)
			

	of.close()


add_label('/home/yunfeng/rstarcnn/lists/basic_info/class_index.txt', 'pre_pre_flownet2_png.txt', 'pre_flownet2_png.txt')
			
